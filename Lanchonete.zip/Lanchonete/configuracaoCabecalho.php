<?php
$p["logo"] = "img/logo.png";
$p["alt_logo"] = "Logotipo Lanchonete";
    $p["links"][0]["link"] = "lanches.php";
    $p["links"][0]["label"] = "Lanches";
    $p["links"][1]["link"] = "bebida.php";
    $p["links"][1]["label"] = "Bebidas";
    $p["links"][2]["link"] = "combo.php";
    $p["links"][2]["label"] = "combos";
    $p["links"][3]["link"] = "acompanhamento.php";
    $p["links"][3]["label"] = "Acompanhamentos";  
?>