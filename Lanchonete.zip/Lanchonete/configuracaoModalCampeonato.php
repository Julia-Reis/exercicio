<?php

$p["id"] = "Campeonato";
$p["titulo"] = "Campeonato";


$p["divRow"][0] = '
<div class="row">
    <div class="form-group col-sm-8 col-8">	                            
        <input type="text" name="nome" 
        id="campeonato" class="form-control" placeholder= "Nome Campeonato..." />
    </div>
    <div class="form-group col-sm-4 col-4">	                            
    <input type="number" name="ano" 
    id="ano" class="form-control" placeholder= "Ano..." />
</div>
</div>';
?>