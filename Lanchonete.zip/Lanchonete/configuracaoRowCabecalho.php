<?php
$p = null;
$p["titulo"] = $titulo;
$p["pesquisa"] = strtolower($titulo);
   
?>