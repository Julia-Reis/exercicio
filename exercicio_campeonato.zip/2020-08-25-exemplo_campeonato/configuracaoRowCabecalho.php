<?php

$p = null;
	$p["pesquisa"] = "time";
	$p["titulo"] = "TIME";
	
	
?>