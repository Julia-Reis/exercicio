<?php
$p = null;

$p["links"][0]["link"] = "index.php";
$p["links"][0]["label"] = "Início";

$p["links"][1]["link"] = "time.php";
$p["links"][1]["label"] = "Time";

$p["links"][2]["link"] = "";
$p["links"][2]["label"] = "Pesquisa";
    

?>